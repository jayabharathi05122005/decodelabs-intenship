import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (classification_report, confusion_matrix,
                             roc_auc_score, roc_curve, precision_score,
                             recall_score, f1_score)
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

# ─── 1. LOAD DATA ────────────────────────────────────────────────────────────
df = pd.read_excel('/mnt/user-data/uploads/Dataset_for_Data_Analytics.xlsx')
print(f"Dataset shape: {df.shape}")

# ─── 2. FEATURE ENGINEERING + FRAUD LABEL ────────────────────────────────────
# Engineer a realistic fraud label (~3% rate) using business rules:
#   • High-value order (TotalPrice > 90th percentile) AND Cancelled  → fraud risk
#   • Gift Card payment AND high TotalPrice AND Returned              → fraud risk
#   • Multiple items (ItemsInCart >= 9) AND Cancelled                → fraud risk
np.random.seed(42)

p90 = df['TotalPrice'].quantile(0.90)

fraud_flag = (
    ((df['TotalPrice'] > p90) & (df['OrderStatus'] == 'Cancelled')) |
    ((df['PaymentMethod'] == 'Gift Card') & (df['TotalPrice'] > p90) & (df['OrderStatus'] == 'Returned')) |
    ((df['ItemsInCart'] >= 9) & (df['OrderStatus'] == 'Cancelled'))
).astype(int)

# Add small random noise to non-fraud to reach ~3% fraud rate
noise_idx = df[fraud_flag == 0].sample(frac=0.005, random_state=42).index
fraud_flag[noise_idx] = 1

df['IsFraud'] = fraud_flag
print(f"\nClass Distribution:\n{df['IsFraud'].value_counts()}")
print(f"Fraud Rate: {df['IsFraud'].mean()*100:.2f}%")

# ─── 3. PREPARE FEATURES ─────────────────────────────────────────────────────
df['DayOfWeek'] = pd.to_datetime(df['Date']).dt.dayofweek
df['Month'] = pd.to_datetime(df['Date']).dt.month

cat_cols = ['Product', 'PaymentMethod', 'OrderStatus', 'ReferralSource', 'CouponCode']
le = LabelEncoder()
for col in cat_cols:
    df[col + '_enc'] = le.fit_transform(df[col].astype(str))

feature_cols = ['Quantity', 'UnitPrice', 'ItemsInCart', 'TotalPrice',
                'DayOfWeek', 'Month'] + [c + '_enc' for c in cat_cols]

X = df[feature_cols].values
y = df['IsFraud'].values

print(f"\nFeatures used: {feature_cols}")

# ─── 4. STRATIFIED TRAIN/TEST SPLIT (before SMOTE!) ──────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"\nTrain size: {X_train.shape[0]} | Test size: {X_test.shape[0]}")
print(f"Train fraud: {y_train.sum()} | Test fraud: {y_test.sum()}")

# ─── 5. BUILD PIPELINES ──────────────────────────────────────────────────────
# Logistic Regression Pipeline (needs StandardScaler)
lr_pipeline = ImbPipeline([
    ('scaler', StandardScaler()),
    ('smote', SMOTE(random_state=42)),
    ('classifier', LogisticRegression(max_iter=1000, random_state=42))
])

# Random Forest Pipeline (tree-based, no scaler needed)
rf_pipeline = ImbPipeline([
    ('smote', SMOTE(random_state=42)),
    ('classifier', RandomForestClassifier(random_state=42, n_jobs=-1))
])

# ─── 6. HYPERPARAMETER GRIDS ─────────────────────────────────────────────────
lr_param_grid = {
    'smote__k_neighbors': [3, 5],
    'classifier__C': [0.01, 0.1, 1.0]
}

rf_param_grid = {
    'smote__k_neighbors': [3, 5],
    'classifier__n_estimators': [100, 200],
    'classifier__max_depth': [10, 20, None]
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# ─── 7. GRIDSEARCHCV ─────────────────────────────────────────────────────────
print("\n--- Training Logistic Regression with GridSearchCV ---")
lr_gs = GridSearchCV(lr_pipeline, lr_param_grid, cv=cv,
                     scoring='roc_auc', n_jobs=-1, verbose=0)
lr_gs.fit(X_train, y_train)
print(f"Best LR params: {lr_gs.best_params_}")
print(f"Best LR CV ROC-AUC: {lr_gs.best_score_:.4f}")

print("\n--- Training Random Forest with GridSearchCV ---")
rf_gs = GridSearchCV(rf_pipeline, rf_param_grid, cv=cv,
                     scoring='roc_auc', n_jobs=-1, verbose=0)
rf_gs.fit(X_train, y_train)
print(f"Best RF params: {rf_gs.best_params_}")
print(f"Best RF CV ROC-AUC: {rf_gs.best_score_:.4f}")

# ─── 8. EVALUATE ON UNTOUCHED TEST SET ───────────────────────────────────────
def evaluate_model(name, model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_prob)
    print(f"\n{'='*50}")
    print(f"  {name} — Test Set Results")
    print(f"{'='*50}")
    print(f"  Precision : {precision:.4f}")
    print(f"  Recall    : {recall:.4f}")
    print(f"  F1 Score  : {f1:.4f}")
    print(f"  ROC-AUC   : {roc_auc:.4f}")
    print(f"\nClassification Report:\n{classification_report(y_test, y_pred)}")
    return y_pred, y_prob, precision, recall, f1, roc_auc

lr_pred, lr_prob, lr_p, lr_r, lr_f1, lr_auc = evaluate_model("Logistic Regression", lr_gs, X_test, y_test)
rf_pred, rf_prob, rf_p, rf_r, rf_f1, rf_auc = evaluate_model("Random Forest", rf_gs, X_test, y_test)

# ─── 9. VISUALIZATIONS ───────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle("Fraud Detection Pipeline — Model Evaluation", fontsize=16, fontweight='bold')

# 9a. Class Distribution
ax = axes[0, 0]
labels = ['Legitimate', 'Fraudulent']
counts = [len(y) - y.sum(), y.sum()]
colors = ['#2196F3', '#F44336']
bars = ax.bar(labels, counts, color=colors, edgecolor='black')
for bar, cnt in zip(bars, counts):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 2,
            f'{cnt}\n({cnt/len(y)*100:.1f}%)', ha='center', va='bottom', fontweight='bold')
ax.set_title('Class Distribution (Original Dataset)', fontweight='bold')
ax.set_ylabel('Count')

# 9b. Confusion Matrix — LR
ax = axes[0, 1]
cm_lr = confusion_matrix(y_test, lr_pred)
sns.heatmap(cm_lr, annot=True, fmt='d', cmap='Blues', ax=ax,
            xticklabels=['Legit', 'Fraud'], yticklabels=['Legit', 'Fraud'])
ax.set_title('Confusion Matrix — Logistic Regression', fontweight='bold')
ax.set_ylabel('Actual')
ax.set_xlabel('Predicted')

# 9c. Confusion Matrix — RF
ax = axes[0, 2]
cm_rf = confusion_matrix(y_test, rf_pred)
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Oranges', ax=ax,
            xticklabels=['Legit', 'Fraud'], yticklabels=['Legit', 'Fraud'])
ax.set_title('Confusion Matrix — Random Forest', fontweight='bold')
ax.set_ylabel('Actual')
ax.set_xlabel('Predicted')

# 9d. ROC Curves
ax = axes[1, 0]
fpr_lr, tpr_lr, _ = roc_curve(y_test, lr_prob)
fpr_rf, tpr_rf, _ = roc_curve(y_test, rf_prob)
ax.plot(fpr_lr, tpr_lr, label=f'LR (AUC={lr_auc:.3f})', color='blue', lw=2)
ax.plot(fpr_rf, tpr_rf, label=f'RF (AUC={rf_auc:.3f})', color='orange', lw=2)
ax.plot([0, 1], [0, 1], 'k--', lw=1, label='Random')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.set_title('ROC Curves', fontweight='bold')
ax.legend()
ax.set_xlim([0, 1])
ax.set_ylim([0, 1.02])

# 9e. Metric Comparison Bar Chart
ax = axes[1, 1]
metrics = ['Precision', 'Recall', 'F1 Score', 'ROC-AUC']
lr_vals = [lr_p, lr_r, lr_f1, lr_auc]
rf_vals = [rf_p, rf_r, rf_f1, rf_auc]
x = np.arange(len(metrics))
width = 0.35
ax.bar(x - width/2, lr_vals, width, label='Logistic Regression', color='#2196F3', alpha=0.85)
ax.bar(x + width/2, rf_vals, width, label='Random Forest', color='#FF9800', alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels(metrics)
ax.set_ylim(0, 1.1)
ax.set_title('Model Metric Comparison', fontweight='bold')
ax.legend()
for i, (lv, rv) in enumerate(zip(lr_vals, rf_vals)):
    ax.text(i - width/2, lv + 0.02, f'{lv:.2f}', ha='center', fontsize=8)
    ax.text(i + width/2, rv + 0.02, f'{rv:.2f}', ha='center', fontsize=8)

# 9f. Feature Importance (RF)
ax = axes[1, 2]
importances = rf_gs.best_estimator_.named_steps['classifier'].feature_importances_
feat_imp = pd.Series(importances, index=feature_cols).sort_values(ascending=True).tail(10)
feat_imp.plot(kind='barh', ax=ax, color='#4CAF50')
ax.set_title('Top Feature Importances (Random Forest)', fontweight='bold')
ax.set_xlabel('Importance')

plt.tight_layout()
plt.savefig('/home/claude/fraud_detection_results.png', dpi=150, bbox_inches='tight')
plt.close()
print("\nVisualization saved.")

# ─── 10. SAVE RESULTS TO EXCEL ───────────────────────────────────────────────
results_data = {
    'Model': ['Logistic Regression', 'Random Forest'],
    'Precision': [round(lr_p, 4), round(rf_p, 4)],
    'Recall': [round(lr_r, 4), round(rf_r, 4)],
    'F1_Score': [round(lr_f1, 4), round(rf_f1, 4)],
    'ROC_AUC': [round(lr_auc, 4), round(rf_auc, 4)],
    'Best_CV_ROC_AUC': [round(lr_gs.best_score_, 4), round(rf_gs.best_score_, 4)],
    'Best_Params': [str(lr_gs.best_params_), str(rf_gs.best_params_)]
}

results_df = pd.DataFrame(results_data)

# Save to Excel with multiple sheets
with pd.ExcelWriter('/home/claude/fraud_detection_report.xlsx', engine='openpyxl') as writer:
    results_df.to_excel(writer, sheet_name='Model_Comparison', index=False)
    df[feature_cols + ['IsFraud']].head(200).to_excel(writer, sheet_name='Sample_Data', index=False)
    pd.DataFrame({'Feature': feature_cols, 'Importance_RF': importances}).sort_values(
        'Importance_RF', ascending=False).to_excel(writer, sheet_name='Feature_Importance', index=False)

print("Excel report saved.")
print("\n✅ Pipeline complete!")
