import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# ─── 1. LOAD & RICH FEATURE ENGINEERING ──────────────────────────────────────
df = pd.read_excel('/mnt/user-data/uploads/Dataset_for_Data_Analytics.xlsx')
df['Date'] = pd.to_datetime(df['Date'])
df['Month'] = df['Date'].dt.month
df['DayOfWeek'] = df['Date'].dt.dayofweek
df['IsWeekend'] = (df['DayOfWeek'] >= 5).astype(int)
df['IsHighValue'] = (df['TotalPrice'] > df['TotalPrice'].quantile(0.75)).astype(int)
df['IsCancelled'] = (df['OrderStatus'] == 'Cancelled').astype(int)
df['IsReturned'] = (df['OrderStatus'] == 'Returned').astype(int)
df['IsDelivered'] = (df['OrderStatus'] == 'Delivered').astype(int)
df['UsedCoupon'] = (~df['CouponCode'].isin(['NONE','None','none',''])).astype(int)
df['IsGiftCard'] = (df['PaymentMethod'] == 'Gift Card').astype(int)
df['IsCreditCard'] = (df['PaymentMethod'] == 'Credit Card').astype(int)
df['IsOnline'] = (df['PaymentMethod'] == 'Online').astype(int)
df['FromSocial'] = (df['ReferralSource'].isin(['Instagram','Social Media','Facebook'])).astype(int)
df['FromEmail'] = (df['ReferralSource'] == 'Email').astype(int)
df['PricePerItem'] = df['TotalPrice'] / df['Quantity']

le = LabelEncoder()
df['Product_enc'] = le.fit_transform(df['Product'])

# Per-customer aggregation
cust = df.groupby('CustomerID').agg(
    TotalSpend      = ('TotalPrice', 'sum'),
    AvgOrderValue   = ('TotalPrice', 'mean'),
    MaxOrderValue   = ('TotalPrice', 'max'),
    OrderCount      = ('OrderID', 'count'),
    AvgQuantity     = ('Quantity', 'mean'),
    AvgUnitPrice    = ('UnitPrice', 'mean'),
    AvgItemsInCart  = ('ItemsInCart', 'mean'),
    PricePerItem    = ('PricePerItem', 'mean'),
    WeekendRate     = ('IsWeekend', 'mean'),
    CancelRate      = ('IsCancelled', 'mean'),
    ReturnRate      = ('IsReturned', 'mean'),
    DeliveryRate    = ('IsDelivered', 'mean'),
    CouponUsageRate = ('UsedCoupon', 'mean'),
    GiftCardRate    = ('IsGiftCard', 'mean'),
    CreditCardRate  = ('IsCreditCard', 'mean'),
    OnlinePayRate   = ('IsOnline', 'mean'),
    SocialRate      = ('FromSocial', 'mean'),
    EmailRate       = ('FromEmail', 'mean'),
    HighValueRate   = ('IsHighValue', 'mean'),
    FavProduct      = ('Product_enc', lambda x: x.mode()[0]),
    SeasonalSpread  = ('Month', 'std'),
).reset_index()

cust['SeasonalSpread'] = cust['SeasonalSpread'].fillna(0)

feature_cols = [
    'TotalSpend','AvgOrderValue','MaxOrderValue','AvgQuantity','AvgUnitPrice',
    'AvgItemsInCart','PricePerItem','WeekendRate','CancelRate','ReturnRate',
    'DeliveryRate','CouponUsageRate','GiftCardRate','CreditCardRate',
    'OnlinePayRate','SocialRate','EmailRate','HighValueRate','SeasonalSpread'
]

X = cust[feature_cols].values
print(f"Customers: {len(cust)}  |  Features: {len(feature_cols)}")

# ─── 2. STANDARDIZE ──────────────────────────────────────────────────────────
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ─── 3. PCA — 95% VARIANCE RULE ──────────────────────────────────────────────
pca_full = PCA(random_state=42)
pca_full.fit(X_scaled)
cumvar = np.cumsum(pca_full.explained_variance_ratio_)
n95 = np.argmax(cumvar >= 0.95) + 1
print(f"PCA components for 95% variance: {n95}")

pca = PCA(n_components=n95, random_state=42)
X_pca = pca.fit_transform(X_scaled)

pca2d = PCA(n_components=2, random_state=42)
X_2d = pca2d.fit_transform(X_scaled)

pca3d = PCA(n_components=3, random_state=42)
X_3d = pca3d.fit_transform(X_scaled)

# ─── 4. ELBOW + SILHOUETTE ────────────────────────────────────────────────────
k_range = range(2, 11)
wcss, sil = [], []
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=15)
    lbl = km.fit_predict(X_pca)
    wcss.append(km.inertia_)
    sil.append(silhouette_score(X_pca, lbl))
    print(f"  K={k}  WCSS={km.inertia_:.1f}  Silhouette={sil[-1]:.4f}")

# Force K=4 for richer business personas (aligned with PPT's persona matrix)
optimal_k = 4
print(f"\nChosen K={optimal_k} for 4 distinct business personas")

# ─── 5. FINAL CLUSTERING ─────────────────────────────────────────────────────
km_final = KMeans(n_clusters=optimal_k, random_state=42, n_init=15)
cust['Cluster'] = km_final.fit_predict(X_pca)
final_sil = silhouette_score(X_pca, cust['Cluster'])
print(f"Final Silhouette Score (K=4): {final_sil:.4f}")

# ─── 6. PERSONA DEFINITION ───────────────────────────────────────────────────
cs = cust.groupby('Cluster')[feature_cols].mean()
spend_order = cs['TotalSpend'].rank()  # 1=lowest

persona_map = {}
for c in range(optimal_k):
    spend  = cs.loc[c,'TotalSpend']
    aov    = cs.loc[c,'AvgOrderValue']
    cancel = cs.loc[c,'CancelRate']
    coupon = cs.loc[c,'CouponUsageRate']
    hv     = cs.loc[c,'HighValueRate']
    size   = (cust['Cluster']==c).sum()

    sp_pct = (spend - cs['TotalSpend'].min()) / (cs['TotalSpend'].max() - cs['TotalSpend'].min())

    if sp_pct >= 0.75:
        name   = "💎 High-Value Champions"
        action = "VIP perks, early product access, loyalty tiers, premium support"
        color  = '#C0392B'
        bg     = '#FADBD8'
    elif sp_pct >= 0.50:
        name   = "🚀 Growth Explorers"
        action = "Bundle offers, upsell campaigns, referral bonuses, milestone rewards"
        color  = '#E67E22'
        bg     = '#FDEBD0'
    elif cancel > cs['CancelRate'].median() + 0.02:
        name   = "⚠️ At-Risk Churn Segment"
        action = "Re-engagement emails, win-back discounts, exit surveys, easier returns"
        color  = '#2980B9'
        bg     = '#D6EAF8'
    else:
        name   = "💡 Budget-Conscious Buyers"
        action = "Flash sales, value bundles, buy-now-pay-later, price comparison alerts"
        color  = '#27AE60'
        bg     = '#D5F5E3'

    persona_map[c] = {'name':name,'action':action,'color':color,'bg':bg}
    print(f"Cluster {c}: {name} | n={size} | Spend={spend:.0f} | CancelRate={cancel:.1%}")

cust['Persona'] = cust['Cluster'].map(lambda x: persona_map[x]['name'])

# ─── 7. VISUALIZATIONS ───────────────────────────────────────────────────────
fig = plt.figure(figsize=(22, 18))
fig.patch.set_facecolor('#F4F6F8')
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

# Plot 1: PCA Cumulative Variance
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('white')
n_show = min(19, len(pca_full.explained_variance_ratio_))
ax1.bar(range(1, n_show+1), pca_full.explained_variance_ratio_[:n_show]*100,
        color='#3498DB', alpha=0.7, label='Individual')
ax1.plot(range(1, n_show+1), cumvar[:n_show]*100, 'r-o', ms=4, label='Cumulative')
ax1.axhline(95, color='gold', ls='--', lw=2, label='95% threshold')
ax1.axvline(n95, color='green', ls='--', lw=2, label=f'n={n95}')
ax1.set_xlabel('Principal Component', fontsize=9)
ax1.set_ylabel('Variance (%)', fontsize=9)
ax1.set_title('Phase 2 — PCA Scree Plot\n(95% Variance Rule)', fontweight='bold')
ax1.legend(fontsize=7)

# Plot 2: Elbow Method
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('white')
ax2.plot(list(k_range), wcss, 'bo-', lw=2, ms=7)
ax2.axvline(optimal_k, color='red', ls='--', lw=2, label=f'Chosen K={optimal_k}')
ax2.fill_betweenx([min(wcss), max(wcss)], optimal_k-0.3, optimal_k+0.3, alpha=0.1, color='red')
ax2.set_xlabel('Number of Clusters (K)', fontsize=9)
ax2.set_ylabel('WCSS', fontsize=9)
ax2.set_title('Phase 3 — Elbow Method\n(K Selection)', fontweight='bold')
ax2.legend()

# Plot 3: Silhouette Scores
ax3 = fig.add_subplot(gs[0, 2])
ax3.set_facecolor('white')
bar_c = ['#E74C3C' if k == optimal_k else '#85C1E9' for k in k_range]
ax3.bar(list(k_range), sil, color=bar_c, edgecolor='black', alpha=0.85)
for k, s in zip(k_range, sil):
    ax3.text(k, s+0.003, f'{s:.3f}', ha='center', fontsize=7.5, fontweight='bold' if k==optimal_k else 'normal')
ax3.set_xlabel('Number of Clusters (K)', fontsize=9)
ax3.set_ylabel('Silhouette Score', fontsize=9)
ax3.set_title('Phase 3 — Silhouette Scores\n(Cluster Quality)', fontweight='bold')
ax3.set_ylim(0, max(sil)*1.18)

# Plot 4: 2D PCA scatter
ax4 = fig.add_subplot(gs[1, :2])
ax4.set_facecolor('white')
for c in range(optimal_k):
    mask = cust['Cluster'] == c
    ax4.scatter(X_2d[mask, 0], X_2d[mask, 1],
                c=persona_map[c]['color'], label=persona_map[c]['name'],
                alpha=0.55, s=25, edgecolors='none')
centroids_scaled_back = pca.inverse_transform(km_final.cluster_centers_)
cents_2d = pca2d.transform(centroids_scaled_back)
ax4.scatter(cents_2d[:,0], cents_2d[:,1], c='black', marker='X', s=220, zorder=10, label='Centroids')
for i, (cx, cy) in enumerate(cents_2d):
    ax4.annotate(f'C{i}', (cx, cy), textcoords='offset points', xytext=(8,5), fontsize=9, fontweight='bold')
ax4.set_xlabel('PC1 — Primary Behavioral Axis', fontsize=9)
ax4.set_ylabel('PC2 — Secondary Behavioral Axis', fontsize=9)
ax4.set_title('Phase 4 — Customer Clusters in PCA Space (2D Projection)', fontweight='bold')
ax4.legend(fontsize=8, loc='upper right', framealpha=0.9)

# Plot 5: Cluster distribution
ax5 = fig.add_subplot(gs[1, 2])
ax5.set_facecolor('white')
sizes = cust.groupby('Cluster').size()
pie_labels = [f"C{i}\n({sizes[i]})" for i in sizes.index]
wedge_props = dict(width=0.6, edgecolor='white', linewidth=2)
ax5.pie(sizes, labels=pie_labels,
        colors=[persona_map[i]['color'] for i in sizes.index],
        autopct='%1.1f%%', startangle=90, textprops={'fontsize': 9},
        wedgeprops=wedge_props)
ax5.set_title('Customer Distribution\nby Cluster', fontweight='bold')

# Plot 6: Feature Heatmap
ax6 = fig.add_subplot(gs[2, :2])
ax6.set_facecolor('white')
heat_features = ['TotalSpend','AvgOrderValue','AvgUnitPrice','AvgItemsInCart',
                 'CancelRate','ReturnRate','CouponUsageRate','HighValueRate','DeliveryRate']
heat_data = cs[heat_features].copy()
heat_norm = (heat_data - heat_data.min()) / (heat_data.max() - heat_data.min() + 1e-9)
heat_norm.index = [f"C{i}: {persona_map[i]['name'].split(' ',1)[1]}" for i in heat_norm.index]
heat_norm.columns = ['Total\nSpend','Avg\nOrder','Avg\nPrice','Avg\nCart',
                     'Cancel\nRate','Return\nRate','Coupon\nRate','HV\nRate','Delivery\nRate']
sns.heatmap(heat_norm.T, annot=True, fmt='.2f', cmap='RdYlGn',
            ax=ax6, linewidths=0.5, cbar_kws={'label':'Normalized (0–1)'})
ax6.set_title('Phase 4 — Cluster Feature Profile Heatmap', fontweight='bold')
ax6.set_xticklabels(ax6.get_xticklabels(), rotation=15, ha='right', fontsize=8.5)
ax6.set_yticklabels(ax6.get_yticklabels(), rotation=0, fontsize=8)

# Plot 7: Spend distribution
ax7 = fig.add_subplot(gs[2, 2])
ax7.set_facecolor('white')
for c in range(optimal_k):
    mask = cust['Cluster'] == c
    vals = cust.loc[mask, 'TotalSpend']
    ax7.hist(vals, bins=18, alpha=0.6, color=persona_map[c]['color'], density=True)
    ax7.axvline(vals.mean(), color=persona_map[c]['color'], lw=2, ls='--')
ax7.set_xlabel('Total Spend (₹)', fontsize=9)
ax7.set_ylabel('Density', fontsize=9)
ax7.set_title('Total Spend Distribution\nby Cluster', fontweight='bold')

fig.suptitle('Project 3: Unsupervised Learning — Customer Segmentation Pipeline\n'
             'Scale → Compress (PCA) → Cluster (K-Means) → Translate (Personas)',
             fontsize=13, fontweight='bold', y=1.01)

plt.savefig('/home/claude/segmentation_results.png', dpi=150, bbox_inches='tight')
plt.close()
print("Visualization saved.")

# ─── 8. EXCEL REPORT ─────────────────────────────────────────────────────────
summary_rows = []
for c in range(optimal_k):
    stats = cs.loc[c]
    size = (cust['Cluster']==c).sum()
    summary_rows.append({
        'Cluster': c,
        'Persona_Name': persona_map[c]['name'],
        'Customer_Count': size,
        'Pct_of_Base': f"{size/len(cust)*100:.1f}%",
        'Avg_TotalSpend': round(stats['TotalSpend'], 2),
        'Avg_OrderValue': round(stats['AvgOrderValue'], 2),
        'Avg_UnitPrice': round(stats['AvgUnitPrice'], 2),
        'Avg_ItemsInCart': round(stats['AvgItemsInCart'], 2),
        'Cancel_Rate': f"{stats['CancelRate']:.1%}",
        'Return_Rate': f"{stats['ReturnRate']:.1%}",
        'Coupon_Usage_Rate': f"{stats['CouponUsageRate']:.1%}",
        'High_Value_Order_Rate': f"{stats['HighValueRate']:.1%}",
        'Strategic_Action': persona_map[c]['action'],
        'Silhouette_Score': round(final_sil, 4),
        'PCA_Components_95pct': n95,
    })

with pd.ExcelWriter('/home/claude/segmentation_report.xlsx', engine='openpyxl') as writer:
    pd.DataFrame(summary_rows).to_excel(writer, sheet_name='Persona_Summary', index=False)
    cust[['CustomerID','Cluster','Persona','TotalSpend','AvgOrderValue',
          'OrderCount','CancelRate','ReturnRate']].to_excel(
        writer, sheet_name='Customer_Assignments', index=False)
    pd.DataFrame({'K': list(k_range),'WCSS': wcss,'Silhouette_Score': sil}).to_excel(
        writer, sheet_name='K_Diagnostics', index=False)
    pd.DataFrame({'PC': range(1, len(pca_full.explained_variance_ratio_)+1),
                  'Explained_Variance': pca_full.explained_variance_ratio_,
                  'Cumulative_Variance': cumvar}).to_excel(
        writer, sheet_name='PCA_Variance', index=False)

print("Excel saved.\n")
print("="*55)
print(f"  Customers      : {len(cust)}")
print(f"  Features       : {len(feature_cols)}")
print(f"  PCA Components : {n95} (95% variance)")
print(f"  Optimal K      : {optimal_k}")
print(f"  Silhouette     : {final_sil:.4f}")
print("="*55)
for c in range(optimal_k):
    size = (cust['Cluster']==c).sum()
    print(f"  C{c}: {persona_map[c]['name']} — {size} customers")
print("="*55)
