"""
==========================================================================
PROJECT 1: ADVANCED EDA & FEATURE ENGINEERING
DecodeLabs Industrial Training Kit — Data Science Track, Batch 2026
==========================================================================

Goal: Transform a raw e-commerce orders dataset into a mathematically
clean, ML-ready dataset by:
    1. Handling missing data via statistical imputation
    2. Identifying and neutralizing outliers (IQR / Z-Score)
    3. Engineering new predictive features

Dataset: Dataset_for_Data_Analytics.xlsx (1200 orders x 14 columns)
==========================================================================
"""

import pandas as pd
import numpy as np
from scipy import stats

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)

INPUT_PATH = '/mnt/user-data/uploads/1781791761775_Dataset_for_Data_Analytics.xlsx'
OUTPUT_PATH = '/mnt/user-data/outputs/Cleaned_Dataset_with_Engineered_Features.xlsx'
REPORT_PATH = '/mnt/user-data/outputs/EDA_Cleaning_Report.txt'

report_lines = []

def log(msg=""):
    """Print to console and capture for the written report."""
    print(msg)
    report_lines.append(str(msg))


# ==========================================================================
# STEP 0: LOAD & INITIAL INSPECTION
# ==========================================================================
log("=" * 78)
log("STEP 0: LOAD & INITIAL INSPECTION")
log("=" * 78)

df = pd.read_excel(INPUT_PATH)
log(f"Raw shape: {df.shape[0]} rows x {df.shape[1]} columns")
log(f"Columns: {list(df.columns)}")

log("\nDtypes:")
log(df.dtypes.to_string())

log("\nMissing values per column:")
missing_summary = df.isnull().sum()
missing_pct = (df.isnull().mean() * 100).round(2)
miss_table = pd.DataFrame({'missing_count': missing_summary, 'missing_pct': missing_pct})
log(miss_table.to_string())


# ==========================================================================
# PHASE 1: SECURING INPUT FIDELITY
# ==========================================================================
log("\n" + "=" * 78)
log("PHASE 1: SECURING INPUT FIDELITY")
log("=" * 78)

# --------------------------------------------------------------------
# 1A. MISSING DATA DECISION MATRIX
# --------------------------------------------------------------------
# Per-column missingness proportion drives the imputation strategy:
#   < 5%    -> Drop rows (preserves distribution, negligible volume loss)
#   5-20%   -> Statistical imputation (median for skewed numeric,
#              group-wise/mode for categorical)
#   > 20%   -> Multi-dimensional estimation (KNN) for numeric,
#              or an explicit "missing" category for categorical fields
#              where missingness itself is informative (MCAR/MAR check)
# --------------------------------------------------------------------
log("\n--- 1A. Missing Data Decision Matrix ---")

only_missing_col = miss_table[miss_table['missing_count'] > 0].index.tolist()
log(f"Columns with missing values: {only_missing_col}")

for col in only_missing_col:
    pct = missing_pct[col]
    log(f"\nColumn '{col}': {pct}% missing")

    if df[col].dtype == object or str(df[col].dtype).startswith('str'):
        # Categorical missingness check: is it MCAR (missing completely at
        # random) or MAR (correlated with another column)?
        log(f"  -> Categorical column. Checking missingness vs OrderStatus, "
            f"PaymentMethod, ReferralSource for MAR pattern...")
        for check_col in ['OrderStatus', 'PaymentMethod', 'ReferralSource']:
            if check_col != col:
                ct = pd.crosstab(df[col].isnull(), df[check_col], normalize='index')
                spread = (ct.max(axis=1) - ct.min(axis=1)).max()
                log(f"     vs {check_col}: max proportion spread = {spread:.3f} "
                    f"({'looks MCAR' if spread < 0.05 else 'possible MAR signal'})")

# CouponCode: 25.75% missing -> exceeds the 20% threshold -> bucket would
# normally call for KNN/multi-dimensional estimation, BUT this is a
# CATEGORICAL field representing "which coupon (if any) was applied to the
# order." A missing CouponCode does not mean "unknown coupon" that we should
# guess via nearest neighbors — it structurally means "no coupon was used."
# Fabricating a coupon code via KNN would inject false promotional history
# into the data and corrupt any downstream discount-related features.
# Decision: encode missingness as an explicit, meaningful category
# "NoCoupon" rather than statistically imputing a value. This preserves
# the true business signal instead of guessing it away.
log("\n--- Decision for 'CouponCode' (25.75% missing) ---")
log("Missingness is approximately uniform across OrderStatus, PaymentMethod,")
log("and ReferralSource (no strong MAR signal) -> consistent with orders that")
log("simply did not use a coupon (structurally absent, not 'unknown').")
log("Treatment: explicit category imputation -> 'NoCoupon' (NOT KNN/mode),")
log("since fabricating a coupon code would distort discount-based features.")

df['CouponCode'] = df['CouponCode'].fillna('NoCoupon')

log(f"\nPost-treatment missing values:\n{df.isnull().sum().to_string()}")


# --------------------------------------------------------------------
# 1B. OUTLIER DETECTION — IQR METHOD
# --------------------------------------------------------------------
log("\n--- 1B. Outlier Detection (IQR Method) ---")

numeric_cols = ['Quantity', 'UnitPrice', 'ItemsInCart', 'TotalPrice']

iqr_bounds = {}
for col in numeric_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    iqr_bounds[col] = (lower, upper)
    n_outliers = ((df[col] < lower) | (df[col] > upper)).sum()
    log(f"{col:12s} | Q1={Q1:9.2f}  Q3={Q3:9.2f}  IQR={IQR:9.2f}  "
        f"bounds=({lower:9.2f}, {upper:9.2f})  outliers={n_outliers}")

# --------------------------------------------------------------------
# 1C. OUTLIER DETECTION — Z-SCORE METHOD (cross-check)
# --------------------------------------------------------------------
log("\n--- 1C. Outlier Detection (Z-Score Method, |z| > 3) ---")
for col in numeric_cols:
    z = np.abs(stats.zscore(df[col]))
    n_outliers = (z > 3).sum()
    log(f"{col:12s} | max |z| = {z.max():.2f}  outliers (|z|>3) = {n_outliers}")

log("\nInterpretation: Z-score flags 0 outliers everywhere (max |z| ~2.93 on")
log("TotalPrice), while IQR flags 8 points on TotalPrice. This divergence is")
log("expected: TotalPrice is right-skewed (skew=0.89) because it is the")
log("PRODUCT of two independent uniform-like fields (Quantity x UnitPrice).")
log("IQR is non-parametric and more sensitive to skew; Z-score assumes")
log("normality and under-flags skewed distributions. Since TotalPrice is")
log("mathematically determined by Quantity and UnitPrice (verified: 0 rows")
log("mismatch), these 8 'outliers' are large-but-legitimate orders (e.g. high")
log("UnitPrice items bought in bulk), NOT data entry errors or sensor glitches.")

# --------------------------------------------------------------------
# 1D. OUTLIER NEUTRALIZATION — WINSORIZATION (capping), not deletion
# --------------------------------------------------------------------
# Per the IPO blueprint: when downstream components need every row (here,
# every order is a real transaction we don't want to discard) cap values
# at the IQR boundary via clipping rather than deleting rows. This
# preserves row count and avoids destroying legitimate high-value orders.
log("\n--- 1D. Outlier Neutralization Strategy ---")
log("Quantity, UnitPrice, ItemsInCart: 0 IQR outliers -> no action needed.")
log("TotalPrice: 8 IQR outliers, but TotalPrice is a deterministic product")
log("of two clean inputs -> capping TotalPrice alone would break the")
log("Quantity x UnitPrice = TotalPrice identity and silently corrupt the data.")
log("Decision: do NOT clip TotalPrice directly. Instead, flag these rows with")
log("an 'IsHighValueOrder' indicator (see Feature Engineering) so models can")
log("treat them as a distinct, legitimate segment rather than noise to remove.")

lower_tp, upper_tp = iqr_bounds['TotalPrice']
df['_iqr_outlier_flag'] = ((df['TotalPrice'] < lower_tp) | (df['TotalPrice'] > upper_tp)).astype(int)
log(f"\nRows flagged as statistical outliers on TotalPrice: {df['_iqr_outlier_flag'].sum()}")


# ==========================================================================
# PHASE 2: FEATURE ENGINEERING
# ==========================================================================
log("\n" + "=" * 78)
log("PHASE 2: FEATURE ENGINEERING (3+ new predictive features)")
log("=" * 78)

# --------------------------------------------------------------------
# FEATURE 1: AveragePricePerItem
# Business logic: distinguishes "few expensive items" vs "many cheap items"
# orders that share the same TotalPrice — a signal TotalPrice alone hides.
# --------------------------------------------------------------------
df['AveragePricePerItem'] = (df['TotalPrice'] / df['ItemsInCart']).round(2)
log("\n[Feature 1] AveragePricePerItem = TotalPrice / ItemsInCart")
log(df['AveragePricePerItem'].describe().to_string())

# --------------------------------------------------------------------
# FEATURE 2: CartFulfillmentRatio
# Business logic: Quantity (units of THIS product ordered) relative to
# ItemsInCart (total distinct items in the cart) -> proxy for how much of
# the basket this single order line represents (cross-sell potential).
# --------------------------------------------------------------------
df['CartFulfillmentRatio'] = (df['Quantity'] / df['ItemsInCart']).round(3)
log("\n[Feature 2] CartFulfillmentRatio = Quantity / ItemsInCart")
log(df['CartFulfillmentRatio'].describe().to_string())

# --------------------------------------------------------------------
# FEATURE 3: OrderMonth / OrderQuarter / IsWeekendOrder (temporal features)
# Business logic: extracting cyclical/calendar structure from the raw
# Date column, which on its own carries no signal for tree/linear models.
# --------------------------------------------------------------------
df['OrderMonth'] = df['Date'].dt.month
df['OrderQuarter'] = df['Date'].dt.quarter
df['IsWeekendOrder'] = df['Date'].dt.dayofweek.isin([5, 6]).astype(int)
log("\n[Feature 3] Temporal features: OrderMonth, OrderQuarter, IsWeekendOrder")
log(f"Weekend orders: {df['IsWeekendOrder'].sum()} / {len(df)} "
    f"({df['IsWeekendOrder'].mean()*100:.1f}%)")

# --------------------------------------------------------------------
# FEATURE 4: HasDiscountCoupon (binary flag) + IsHighValueOrder
# Business logic: HasDiscountCoupon converts the 3-coupon-code + "NoCoupon"
# categorical into a clean binary predictor of discount usage.
# IsHighValueOrder operationalizes the IQR outlier flag from Phase 1 as a
# legitimate, model-ready feature instead of discarding the information.
# --------------------------------------------------------------------
df['HasDiscountCoupon'] = (df['CouponCode'] != 'NoCoupon').astype(int)
df['IsHighValueOrder'] = df['_iqr_outlier_flag']
df.drop(columns=['_iqr_outlier_flag'], inplace=True)
log("\n[Feature 4] HasDiscountCoupon (binary) and IsHighValueOrder (IQR-flag-based)")
log(f"HasDiscountCoupon=1: {df['HasDiscountCoupon'].sum()} orders")
log(f"IsHighValueOrder=1:  {df['IsHighValueOrder'].sum()} orders")

# --------------------------------------------------------------------
# FEATURE 5: One-Hot Encoding for low-cardinality categoricals
# Per the deck: label-encoding nominal categories creates false ordinal
# distance (e.g. Tablet=3x Laptop). One-hot maps each category to its own
# orthogonal axis, which is the mathematically correct encoding for
# unordered nominal variables headed into a numeric optimizer.
# --------------------------------------------------------------------
ohe_cols = ['Product', 'PaymentMethod', 'OrderStatus', 'ReferralSource']
df_encoded = pd.get_dummies(df, columns=ohe_cols, prefix=ohe_cols, drop_first=False)
log(f"\n[Feature 5] One-Hot Encoded columns: {ohe_cols}")
log(f"Shape after encoding: {df_encoded.shape}")


# ==========================================================================
# PHASE 3: MULTICOLLINEARITY CHECK
# ==========================================================================
log("\n" + "=" * 78)
log("PHASE 3: MULTICOLLINEARITY CHECK")
log("=" * 78)

corr_check_cols = ['Quantity', 'UnitPrice', 'ItemsInCart', 'TotalPrice',
                    'AveragePricePerItem', 'CartFulfillmentRatio']
corr_matrix = df[corr_check_cols].corr().abs()
log("\nAbsolute correlation matrix (engineered numeric features):")
log(corr_matrix.round(3).to_string())

# Isolate upper triangle, flag pairs > 0.80
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
high_corr_pairs = [(col, row, upper.loc[row, col])
                    for col in upper.columns for row in upper.index
                    if pd.notnull(upper.loc[row, col]) and upper.loc[row, col] > 0.80]

log(f"\nHighly correlated pairs (>0.80): {high_corr_pairs if high_corr_pairs else 'None found'}")
log("Note: TotalPrice is intentionally kept despite being derived from")
log("Quantity x UnitPrice, since it is the natural target/label candidate for")
log("downstream regression tasks; Quantity and UnitPrice are retained as the")
log("interpretable drivers behind it.")


# ==========================================================================
# FINAL VALIDATION & EXPORT
# ==========================================================================
log("\n" + "=" * 78)
log("FINAL VALIDATION")
log("=" * 78)

log(f"\nFinal shape (pre-encoding, for readability): {df.shape}")
log(f"Final shape (one-hot encoded, ML-ready): {df_encoded.shape}")
log(f"\nRemaining missing values: {df.isnull().sum().sum()}")
log(f"New engineered features: AveragePricePerItem, CartFulfillmentRatio, "
    f"OrderMonth, OrderQuarter, IsWeekendOrder, HasDiscountCoupon, IsHighValueOrder")

log("\nFinal column list (cleaned, pre-encoding):")
log(str(list(df.columns)))

log("\nSample of cleaned + engineered data:")
log(df.head(5).to_string())

# Export both versions: human-readable cleaned data, and ML-ready one-hot version
with pd.ExcelWriter(OUTPUT_PATH, engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Cleaned_Data', index=False)
    df_encoded.to_excel(writer, sheet_name='ML_Ready_OneHot', index=False)
    miss_table.to_excel(writer, sheet_name='Missingness_Summary')
    corr_matrix.round(3).to_excel(writer, sheet_name='Correlation_Matrix')

log(f"\nSaved cleaned dataset to: {OUTPUT_PATH}")

with open(REPORT_PATH, 'w') as f:
    f.write("\n".join(report_lines))

log(f"Saved full text report to: {REPORT_PATH}")
log("\n" + "=" * 78)
log("PIPELINE COMPLETE")
log("=" * 78)
